document.addEventListener('DOMContentLoaded', () => {
  const modelDropdown = document.getElementById('model-dropdown');
  const formContainer = document.getElementById('form-container');
  const dataForm = document.getElementById('data-form');
  const dataTableBody = document.querySelector('#data-table tbody');
  const dataTable = document.getElementById('data-table');

  let currentModel = null;
  let data = []; // Store data for each model

  // Sample data
  const puc_group = [
    { code: 1, name: 'ACTIVO', level: 1, naturaleza: 1 },
    { code: 2, name: 'PASIVO', level: 1, naturaleza: 2 },
    { code: 3, name: 'PATRIMONIO', level: 2, naturaleza: 1 },
    { code: 4, name: 'INGRESOS', level: 2, naturaleza: 1 },
    { code: 5, name: 'GASTOS', level: 1, naturaleza: 1 },
    { code: 6, name: 'COSTO DE VENTA', level: 1, naturaleza: 1 },
    { code: 7, name: 'COSTO DE PRODUCCION Y OPERACION', level: 1, naturaleza: 1 },
    { code: 8, name: 'CUENTAS DE ORDEN DEUDORAS', level: 1, naturaleza: 1 },
    { code: 9, name: 'CUENTAS DE ORDEN ACREEDORAS', level: 2, naturaleza: 1 },
  ];

  const puc_mayor = [
    { code: 11, name: 'DISPONIBLE', level: 2, naturaleza: 1 },
    { code: 12, name: 'INVERSIONES', level: 2, naturaleza: 1 },
    { code: 13, name: 'DEUDORES', level: 2, naturaleza: 1 },
    { code: 14, name: 'INVENTARIOS', level: 2, naturaleza: 1 },
    { code: 15, name: 'PROPIEDADES, PLANTA Y EQUIPO', level: 2, naturaleza: 1 },
    { code: 16, name: 'INTANGIBLES', level: 2, naturaleza: 1 },
    { code: 17, name: 'DIFERIDOS', level: 2, naturaleza: 1 },
    { code: 18, name: 'OTROS ACTIVOS', level: 2, naturaleza: 1 },
    { code: 19, name: 'VALORIZACIONES', level: 2, naturaleza: 1 },
    { code: 21, name: 'OBLIGACIONES FINANCIERAS', level: 2, naturaleza: 1 },
  ];

  const puc_subaccount = [
    { code: 1105, name: 'CAJA', level: 3, naturaleza: 1 },
    { code: 1110, name: 'BANCOS', level: 3, naturaleza: 1 },
    { code: 1115, name: 'REMESAS EN TRÁNSITO', level: 3, naturaleza: 1 },
    { code: 1120, name: 'CUENTAS DE AHORRO', level: 3, naturaleza: 1 },
    { code: 1125, name: 'FONDOS', level: 3, naturaleza: 1 },
    { code: 1205, name: 'ACCIONES', level: 3, naturaleza: 1 },
    { code: 1210, name: 'CUOTAS O PARTES DE INTERÉS SOCIAL', level: 3, naturaleza: 1 },
    { code: 1215, name: 'BONOS', level: 3, naturaleza: 1 },
  ];

  const puc_detailaccount = [
    { code: 110505, name: 'Caja general', level: 4, naturaleza: 1 },
    { code: 110510, name: 'Cajas menores', level: 4, naturaleza: 1 },
    { code: 110515, name: 'Moneda extranjera', level: 4, naturaleza: 1 },
    { code: 111005, name: 'Moneda nacional', level: 4, naturaleza: 1 },
    { code: 111010, name: 'Moneda extranjera', level: 4, naturaleza: 1 },
    { code: 111505, name: 'Moneda nacional', level: 4, naturaleza: 1 },
    { code: 111510, name: 'Moneda extranjera', level: 4, naturaleza: 1 },
    { code: 112005, name: 'Bancos', level: 4, naturaleza: 1 },
  ];

  const dataMap = {
    'GrupoCuenta': puc_group,
    'CuentaMayor': puc_mayor,
    'SubCuenta': puc_subaccount,
    'CuentaDetalle': puc_detailaccount,
  };

  modelDropdown.addEventListener('change', (event) => {
    const selectedModelName = event.target.value;
    currentModel = window.models.find(model => model.name === selectedModelName);

    if (currentModel) {
      generateForm(currentModel);
      // Load data from the specific array instead of local storage
      loadData(selectedModelName);
    } else {
      dataForm.innerHTML = '';
      dataTableBody.innerHTML = '';
    }
  });

  function generateForm(model) {
    dataForm.innerHTML = ''; // Clear previous form

    model.fields.forEach(field => {
      const label = document.createElement('label');
      label.textContent = field.label;
      label.setAttribute('for', field.name);

      let input;
      if (field.type === 'textarea') {
        input = document.createElement('textarea');
      } else if (field.type === 'checkbox') {
        input = document.createElement('input');
        input.type = 'checkbox';
      } else {
        input = document.createElement('input');
        input.type = field.type || 'text';
      }
      input.id = field.name;
      input.name = field.name;

      dataForm.appendChild(label);
      dataForm.appendChild(input);
    });

    const submitButton = document.createElement('button');
    submitButton.textContent = 'Guardar';
    submitButton.type = 'button';
    submitButton.addEventListener('click', saveData);
    dataForm.appendChild(submitButton);
  }

  function saveData() {
    if (!currentModel) return;

    const newDataItem = {};
    currentModel.fields.forEach(field => {
      const inputElement = document.getElementById(field.name);
      newDataItem[field.name] = inputElement.type === 'checkbox' ? inputElement.checked : inputElement.value;
    });

    data.push(newDataItem);
    // No need to save to local storage since we're using predefined data
    // saveDataToLocalStorage(currentModel.name);
    renderTable(currentModel);
    dataForm.reset();
  }

  function saveDataToLocalStorage(modelName) {
    localStorage.setItem(modelName, JSON.stringify(data));
  }

  function loadData(modelName) {
    // Load data from the corresponding data array
    data = dataMap[modelName] || [];
    if (currentModel) {
      renderTable(currentModel);
    }
  }

  function renderTable(model) {
    dataTableBody.innerHTML = ''; // Clear existing table rows
    const thead = document.querySelector('#data-table thead tr');
    thead.innerHTML = '<th>Código</th><th>Nombre</th><th>Acciones</th>';

    model.fields.forEach(field => {
      const th = document.createElement('th');
      th.textContent = field.label;
      thead.appendChild(th);
    });

    data.forEach((item, index) => {
      const row = document.createElement('tr');

      // Add action buttons
      const actionsCell = document.createElement('td');
      actionsCell.classList.add('actions');

      const editButton = document.createElement('button');
      editButton.innerHTML = '<i class="fas fa-edit"></i> Editar';
      editButton.addEventListener('click', () => editItem(index));
      actionsCell.appendChild(editButton);

      const deleteButton = document.createElement('button');
      deleteButton.innerHTML = '<i class="fas fa-trash-alt"></i> Eliminar';
      deleteButton.addEventListener('click', () => deleteItem(index));
      actionsCell.appendChild(deleteButton);

      row.appendChild(actionsCell);

      model.fields.forEach(field => {
        const td = document.createElement('td');
        td.textContent = item[field.name] || '';
        row.appendChild(td);
      });

      dataTableBody.appendChild(row);
    });
  }

  function editItem(index) {
    // Implement edit functionality here
    alert(`Edit item at index ${index}`);
  }

  function deleteItem(index) {
    data.splice(index, 1);
    // No need to save to local storage since we're using predefined data
    // saveDataToLocalStorage(currentModel.name);
    renderTable(currentModel);
  }
});